﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PizzaApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void CalculateTotalPrice(){
            label_TotalPrice.Text = "$" + Convert.ToString((Convert.ToByte(box_Size.Tag) + Convert.ToByte(box_Crust.Tag) + Convert.ToByte(box_Toppings.Tag))*Convert.ToInt32(numericUpDown1.Value));
        }
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            label_Size.Text = radioButton1.Text;
            box_Size.Tag = 20;
            CalculateTotalPrice();
        }
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            label_Size.Text = radioButton2.Text;
            box_Size.Tag = 30;
            CalculateTotalPrice() ;
        }
        private void radioButton3_CheckedChanged_1(object sender, EventArgs e)
        {
            label_Size.Text = radioButton3.Text;
            box_Size.Tag = 40;
            CalculateTotalPrice();
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            label_CrustType.Text = radioButton5.Text;
            box_Crust.Tag = 10;
            CalculateTotalPrice();
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            label_CrustType.Text = radioButton6.Text;
            box_Crust.Tag = 0;
            CalculateTotalPrice();
        }

        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {
            label_WhereToEat.Text = radioButton7.Text;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            label_WhereToEat.Text=radioButton4.Text;
        }

        private void checkBox1_CheckStateChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                box_Toppings.Tag = Convert.ToSByte(box_Toppings.Tag) + 5;
                label_Toppings.Text += checkBox1.Text + ",";
            }
            else
            {
                box_Toppings.Tag = Convert.ToSByte(box_Toppings.Tag) - 5;
                label_Toppings.Text = label_Toppings.Text.Replace(checkBox1.Text + ",", "");
            }
            CalculateTotalPrice();
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked)
            {
                box_Toppings.Tag = Convert.ToSByte(box_Toppings.Tag) + 5;
                label_Toppings.Text += checkBox4.Text + ",";
            }
            else { 
                box_Toppings.Tag = Convert.ToSByte(box_Toppings.Tag) - 5;
                label_Toppings.Text = label_Toppings.Text.Replace(checkBox4.Text + ",", "");
            }
            CalculateTotalPrice();
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                box_Toppings.Tag = Convert.ToSByte(box_Toppings.Tag) + 5;
                label_Toppings.Text += checkBox2.Text + ",";
            }
            else
            {
                box_Toppings.Tag = Convert.ToSByte(box_Toppings.Tag) - 5;
                label_Toppings.Text = label_Toppings.Text.Replace(checkBox2.Text + ",", "");
            }
            CalculateTotalPrice();
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                box_Toppings.Tag = Convert.ToSByte(box_Toppings.Tag) + 5;
                label_Toppings.Text += checkBox3.Text + ",";
            }
            else { 
                box_Toppings.Tag = Convert.ToSByte(box_Toppings.Tag) - 5;
                label_Toppings.Text = label_Toppings.Text.Replace(checkBox3.Text + ",", "");
            }
            CalculateTotalPrice();
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked) {
                box_Toppings.Tag = Convert.ToSByte(box_Toppings.Tag) + 5;
                label_Toppings.Text += checkBox5.Text + ",";
            }
            else
            {
                box_Toppings.Tag = Convert.ToSByte(box_Toppings.Tag) - 5;
                label_Toppings.Text = label_Toppings.Text.Replace(checkBox5.Text + ",", "");
            }
            CalculateTotalPrice();
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox6.Checked) { 
                box_Toppings.Tag = Convert.ToSByte(box_Toppings.Tag) + 5;
                label_Toppings.Text += checkBox6.Text+",";
            }
            else
            {
                box_Toppings.Tag = Convert.ToSByte(box_Toppings.Tag) - 5;
                label_Toppings.Text = label_Toppings.Text.Replace(checkBox6.Text + ",", "");
            }
            CalculateTotalPrice();
        }

        private void btn_Order_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Confirm Order", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button1) == DialogResult.Yes) {
                MessageBox.Show("Order Confirmed!");
                box_Crust.Enabled = false;
                box_Toppings.Enabled = false;
                box_Size.Enabled = false;
                box_WhereToEat.Enabled = false;
                btn_Order.Enabled = false;
                numericUpDown1.Enabled = false;
            }
        }

        private void btn_Reset_Click(object sender, EventArgs e)
        {
            box_Crust.Enabled = true;
            box_Toppings.Enabled = true;
            box_Size.Enabled = true;
            box_WhereToEat.Enabled = true;
            numericUpDown1 .Enabled = true;
            numericUpDown1.Value = 1;
            btn_Order.Enabled = true;
            radioButton1.Checked = true;
            radioButton6 .Checked = true;
            checkBox1.Checked = false;
            checkBox2 .Checked = false;
            checkBox3 .Checked = false;
            checkBox4.Checked = false;
            checkBox5.Checked = false;
            checkBox6 .Checked = false;
            label_TotalPrice.Text = "$20";
            label_Toppings.Text = "";
            label_Size.Text = "Small";
            label_CrustType.Text = "Thin";
        }
        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            CalculateTotalPrice();
        }

    }
}
